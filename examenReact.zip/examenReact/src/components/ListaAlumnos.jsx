import { useState } from "react";
import Modal from "./Modal";

// Componente que muestra la lista de alumnos y permite ver sus detalles
export default function ListaAlumnos({ alumnos, prestamos, libros }) {

  // Estado para guardar qué alumno está seleccionado para ver detalles
  const [alumnoSeleccionado, setAlumnoSeleccionado] = useState(null);

  return (
    <div>
      <h2>Alumnos</h2>

      {/* Listado de alumnos en pantalla */}
      <ul>
        {alumnos.map(alumno => (
          <li key={alumno.id}>
            {/* Nombre del alumno */}
            {alumno.nombre}
            <img src={alumno.imagen} alt={alumno.nombre} width={50} />

            {/* Botón que abre el modal mostrando los detalles de ese alumno */}
            <button onClick={() => setAlumnoSeleccionado(alumno)}>
              Ver detalles
            </button>
          </li>
        ))}
      </ul>

      {/* Si hay un alumno seleccionado, mostrar el Modal */}
      {alumnoSeleccionado && (
        <Modal
          visible={true}                     // Forzamos que el modal esté visible
          onClose={() => setAlumnoSeleccionado(null)} // Cierra el modal
        >

          {/* Información del alumno */}
          <h2>{alumnoSeleccionado.nombre}</h2>
          <p><strong>ID:</strong> {alumnoSeleccionado.id}</p>
          <p><strong>Curso:</strong> {alumnoSeleccionado.curso}</p>

          {/* Préstamos del alumno */}
          <h4>Préstamos:</h4>
          <ul>
            {prestamos
              // Filtrar solamente sus préstamos
              .filter(p => p.alumnoId === alumnoSeleccionado.id)
              // Renderizar cada préstamo
              .map(p => {
                // Buscar el libro correspondiente al préstamo
                const libro = libros.find(l => l.id === p.libroId);

                return (
                  <li key={p.id}>
                    {/* Mostrar datos del préstamo */}
                    {libro?.titulo} - {p.estado} - {p.fechaPrestamo} a {p.fechaDevolucionPrevista}
                  </li>
                );
              })}
          </ul>
        </Modal>
      )}
    </div>
  );
}
